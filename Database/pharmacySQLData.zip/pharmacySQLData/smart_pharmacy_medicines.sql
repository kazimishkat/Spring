-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: smart_pharmacy
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medicines`
--

DROP TABLE IF EXISTS `medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `is_active` bit(1) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `brand_name` varchar(150) NOT NULL,
  `default_purchase_price` decimal(12,2) DEFAULT NULL,
  `default_selling_price` decimal(12,2) DEFAULT NULL,
  `description` text,
  `dosage_form` enum('CAPSULE','CREAM','DROPS','GEL','INHALER','INJECTION','LOTION','OINTMENT','PATCH','POWDER','SACHET','SPRAY','SUPPOSITORY','SUSPENSION','SYRUP','TABLET') DEFAULT NULL,
  `drug_schedule` enum('CONTROLLED_SUBSTANCE','NARCOTIC','OTC','PRESCRIPTION_REQUIRED') DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(150) DEFAULT NULL,
  `medicine_code` varchar(30) NOT NULL,
  `reorder_level` int DEFAULT NULL,
  `reorder_quantity` int DEFAULT NULL,
  `storage_condition` enum('COLD_CHAIN','FROZEN','PROTECT_FROM_LIGHT','PROTECT_FROM_MOISTURE','REFRIGERATED','ROOM_TEMPERATURE') DEFAULT NULL,
  `strength` varchar(50) DEFAULT NULL,
  `unit_of_measure` enum('AMPOULE','BOTTLE','BOX','JAR','PIECE','SACHET','STRIP','TUBE','VIAL') DEFAULT NULL,
  `units_per_pack` int DEFAULT NULL,
  `vat_percentage` decimal(5,2) DEFAULT NULL,
  `generic_medicine_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKld4htm04xvhtv2rfn0motojql` (`medicine_code`),
  KEY `FKgwlp43x4866mnkixp61dv8q2a` (`generic_medicine_id`),
  CONSTRAINT `FKgwlp43x4866mnkixp61dv8q2a` FOREIGN KEY (`generic_medicine_id`) REFERENCES `generic_medicines` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicines`
--

LOCK TABLES `medicines` WRITE;
/*!40000 ALTER TABLE `medicines` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-01 18:41:02
